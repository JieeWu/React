export default function ChildB() {
  return (
    <>
      <h1>ChildB</h1>
    </>
  )
}
