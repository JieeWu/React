import Parent from './parent'

export default function Grandparent() {
  return (
    <>
      <h1>Grandparent</h1>
      <Parent />
    </>
  )
}
