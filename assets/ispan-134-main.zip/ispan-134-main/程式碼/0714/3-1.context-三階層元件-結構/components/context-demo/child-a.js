export default function ChildA() {
  return (
    <>
      <h1>ChildA</h1>
    </>
  )
}
