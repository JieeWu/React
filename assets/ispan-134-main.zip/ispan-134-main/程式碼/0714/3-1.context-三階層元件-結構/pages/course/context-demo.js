import Grandparent from '@/components/context-demo/grandparent'

export default function ContextDemo() {
  return (
    <>
      <h1>Context(環境)範例</h1>
      <Grandparent />
    </>
  )
}
