import React from 'react'
import TodoIndex from '@/components/todo'

export default function Todo() {
  return (
    <>
      <h1>Todo待辨事項</h1>
      <TodoIndex />
    </>
  )
}
