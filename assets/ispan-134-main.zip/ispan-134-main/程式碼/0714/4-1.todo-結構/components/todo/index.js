import React from 'react'

export default function TodoIndex() {
  return (
    <>
      <input type="text" />
      <hr />
      <ul>
        <li>買牛奶</li>
        <li>學react</li>
      </ul>
    </>
  )
}
