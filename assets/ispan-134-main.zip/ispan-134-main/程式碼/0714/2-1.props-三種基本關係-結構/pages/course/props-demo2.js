import React from 'react'
import Parent from '@/components/props-demo2/parent'

export default function PropsDemo() {
  return (
    <>
      <Parent />
    </>
  )
}
