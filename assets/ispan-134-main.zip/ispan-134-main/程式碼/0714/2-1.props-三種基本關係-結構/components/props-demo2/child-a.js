import React from 'react'

export default function ChildA() {
  return <>ChildA</>
}
