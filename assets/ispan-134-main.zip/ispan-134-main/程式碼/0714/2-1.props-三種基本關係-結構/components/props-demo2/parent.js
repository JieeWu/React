import React from 'react'
import ChildA from './child-a'

export default function Parent() {
  return (
    <>
      <h1>Parent</h1>
      <ChildA />
    </>
  )
}
