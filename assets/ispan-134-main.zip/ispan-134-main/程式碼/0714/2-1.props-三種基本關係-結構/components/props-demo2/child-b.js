import React from 'react'

export default function ChildB() {
  return <>ChildB</>
}
