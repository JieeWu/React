import React from 'react'

export default function RefsForm() {
  return (
    <>
      <h2>Refs Form</h2>
    </>
  )
}
