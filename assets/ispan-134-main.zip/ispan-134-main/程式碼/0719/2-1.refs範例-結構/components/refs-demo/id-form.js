import React from 'react'

export default function IdForm() {
  return (
    <>
      <h2>Id Form</h2>
    </>
  )
}
