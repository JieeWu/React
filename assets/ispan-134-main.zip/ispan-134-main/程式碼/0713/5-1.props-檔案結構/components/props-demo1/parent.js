import React from 'react'

export default function Parent() {
  return (
    <div>Parent</div>
  )
}
