import React from 'react'

export default function Child() {
  return (
    <div>Child</div>
  )
}
