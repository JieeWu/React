import React from 'react'
import Parent from '@/components/props-demo1/Parent'

export default function PropsDemo() {
  return (
    <>
      <Parent />
    </>
  )
}
