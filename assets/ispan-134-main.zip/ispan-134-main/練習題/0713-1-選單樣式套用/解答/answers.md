https://codesandbox.io/s/homework-1-array-1mm18

https://codesandbox.io/s/homework-1-array-forked-5q9xt4

https://codesandbox.io/s/homework-1-object-e0qytq
