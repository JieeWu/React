# 畫出表格

用 react，然後使用 data 資料夾 中的 json 資料與 js 資料檔案，呈現一個產品的資料表格。

> 註: css檔案直接複製到styles資料夾，在`/pages/_app.js`檔案中導入即可。
